#include <BluetoothSerial.h>

BluetoothSerial SerialBT;

// ========== PINES ==========
// Motores DRV8833
#define M1_ADELANTE 21
#define M1_ATRAS    19
#define M2_ADELANTE 18
#define M2_ATRAS     5

// Sensores TCRT5000 (Línea)
#define TCRT_DELANTERO_IZQ 32
#define TCRT_DELANTERO_DER 33
#define TCRT_TRASERO_IZQ   25
#define TCRT_TRASERO_DER   26

// Sensor 2Y0A21 (Distancia) 
#define PIN_SENSOR_2Y0 34

// LEDs
#define LED_DETECCION 15    // LED detección 2Y0
#define LED_MANUAL 2        // LED modo manual
#define LED_AUTONOMO 4      // LED modo autónomo

// ========== VARIABLES ==========
bool modoAutonomo = true;
int umbralFrontal = 2000;
int umbralTrasero = 2000;
int UMBRAL_DISTANCIA = 2500;

// ========== SETUP ==========
void setup() {
  Serial.begin(115200);
  SerialBT.begin("SumoBot-Simple");
  
  configurarPines();
  SerialBT.println("ROBOT SUMO LISTO");
  SerialBT.println("K=Calibrar, C=Cambiar modo, U/D/R/L/S=Manual");
}

void configurarPines() {
  // Motores
  pinMode(M1_ADELANTE, OUTPUT);
  pinMode(M1_ATRAS, OUTPUT);
  pinMode(M2_ADELANTE, OUTPUT);
  pinMode(M2_ATRAS, OUTPUT);
  
  // Sensores TCRT
  pinMode(TCRT_DELANTERO_IZQ, INPUT);
  pinMode(TCRT_DELANTERO_DER, INPUT);
  pinMode(TCRT_TRASERO_IZQ, INPUT);
  pinMode(TCRT_TRASERO_DER, INPUT);
  
  // Sensor 2Y0 (siempre activo)
  pinMode(PIN_SENSOR_2Y0, INPUT);
  
  // LEDs
  pinMode(LED_DETECCION, OUTPUT);
  pinMode(LED_MANUAL, OUTPUT);
  pinMode(LED_AUTONOMO, OUTPUT);
  
  coastMotores();
  actualizarLEDs();
}

// ========== LOOP PRINCIPAL ==========
void loop() {
  procesarComandosBT();
  
  if (modoAutonomo) {
    modoAutonomoCompleto();
  } else {
    modoManualCompleto();
  }
  
  delay(50);
}

// ========== PROCESAR COMANDOS BLUETOOTH ==========
void procesarComandosBT() {
  if (SerialBT.available()) {
    char comando = SerialBT.read();
    Serial.print("Comando: "); Serial.println(comando);
    
    switch(comando) {
      case 'K': case 'k': 
        calibrarSensores();
        break;
      case 'C': case 'c': 
        setModoAutonomo(!modoAutonomo);
        break;
      case 'U': case 'u': 
        if (!modoAutonomo) comandoManual('U');
        break;
      case 'D': case 'd': 
        if (!modoAutonomo) comandoManual('D');
        break;
      case 'R': case 'r': 
        if (!modoAutonomo) comandoManual('R');
        break;
      case 'L': case 'l': 
        if (!modoAutonomo) comandoManual('L');
        break;
      case 'S': case 's': 
        if (!modoAutonomo) comandoManual('S');
        break;
    }
  }
}

// ========== MODO AUTÓNOMO ==========
void modoAutonomoCompleto() {
  // 1. PRIORIDAD: Detectar línea (TCRT)
  if (detectarLineaFrontal()) {
    evadeFrontWhite();
    return;
  } 
  if (detectarLineaTrasera()) {
    evadeBackWhite();
    return;
  }
  
  // 2. Detectar oponente (2Y0)
  int distancia = analogRead(PIN_SENSOR_2Y0);
  if (distancia > UMBRAL_DISTANCIA) {
    ataqueFrontal();
  } else {
    buscarOponente();
  }
}

// ========== MODO MANUAL ==========
void modoManualCompleto() {
  //IGNORAR 2Y0
  if (detectarLineaFrontal() || detectarLineaTrasera()) {
    coastMotores();
    SerialBT.println("LINEA_DETECTADA - Motores detenidos");
  }
}

// ========== COMANDOS MANUALES ==========
void comandoManual(char comando) {
  coastMotores();
  
  switch(comando) {
    case 'U': // Adelante
      digitalWrite(M1_ADELANTE, HIGH);
      digitalWrite(M2_ADELANTE, HIGH);
      SerialBT.println("ADELANTE");
      break;
    case 'D': // Atrás
      digitalWrite(M1_ATRAS, HIGH);
      digitalWrite(M2_ATRAS, HIGH);
      SerialBT.println("ATRAS");
      break;
    case 'R': // Derecha
      digitalWrite(M1_ADELANTE, HIGH);
      digitalWrite(M2_ATRAS, HIGH);
      SerialBT.println("DERECHA");
      break;
    case 'L': // Izquierda
      digitalWrite(M1_ATRAS, HIGH);
      digitalWrite(M2_ADELANTE, HIGH);
      SerialBT.println("IZQUIERDA");
      break;
    case 'S': // Stop
      coastMotores();
      SerialBT.println("STOP");
      break;
  }
}

// ========== DETECCIÓN SENSORES ==========
bool detectarLineaFrontal() {
  int left = analogRead(TCRT_DELANTERO_IZQ);
  int right = analogRead(TCRT_DELANTERO_DER);
  bool detectado = (left > umbralFrontal) || (right > umbralFrontal);
  if (detectado) SerialBT.println("LINEA_FRONTAL");
  return detectado;
}

bool detectarLineaTrasera() {
  int left = analogRead(TCRT_TRASERO_IZQ);
  int right = analogRead(TCRT_TRASERO_DER);
  bool detectado = (left > umbralTrasero) || (right > umbralTrasero);
  if (detectado) SerialBT.println("LINEA_TRASERA");
  return detectado;
}

// ========== MOVIMIENTOS AUTÓNOMOS ==========
void ataqueFrontal() {
  digitalWrite(LED_DETECCION, HIGH);
  SerialBT.println("ATAQUE_FRONTAL");
  digitalWrite(M1_ADELANTE, HIGH);
  digitalWrite(M2_ADELANTE, HIGH);
}

void evadeFrontWhite() {
  SerialBT.println("EVADE_FRONTAL");
  digitalWrite(M1_ATRAS, HIGH);    // Izquierda atrás
  digitalWrite(M2_ADELANTE, HIGH); // Derecha adelante
  delay(500);
  coastMotores();
}

void evadeBackWhite() {
  SerialBT.println("EVADE_TRASERO");
  digitalWrite(M1_ADELANTE, HIGH); // Izquierda adelante
  digitalWrite(M2_ATRAS, HIGH);    // Derecha atrás
  delay(500);
  coastMotores();
}

void buscarOponente() {
  static unsigned long lastSearch = 0;
  static int searchState = 0;
  
  if (millis() - lastSearch > 2000) {
    searchState = (searchState + 1) % 4;
    lastSearch = millis();
    
    switch(searchState) {
      case 0: 
        digitalWrite(M1_ADELANTE, HIGH);
        digitalWrite(M2_ADELANTE, HIGH);
        break;
      case 1: 
        digitalWrite(M1_ADELANTE, LOW);
        digitalWrite(M2_ADELANTE, HIGH);
        break;
      case 2: 
        digitalWrite(M1_ADELANTE, HIGH);
        digitalWrite(M2_ADELANTE, HIGH);
        break;
      case 3: 
        digitalWrite(M1_ADELANTE, HIGH);
        digitalWrite(M2_ADELANTE, LOW);
        break;
    }
    delay(300);
    coastMotores();
  }
}

void coastMotores() {
  digitalWrite(M1_ADELANTE, LOW);
  digitalWrite(M1_ATRAS, LOW);
  digitalWrite(M2_ADELANTE, LOW);
  digitalWrite(M2_ATRAS, LOW);
  digitalWrite(LED_DETECCION, LOW);
}

// ========== CONFIGURACIÓN MODO ==========
void setModoAutonomo(bool autonomo) {
  modoAutonomo = autonomo;
  coastMotores();
  actualizarLEDs();
  SerialBT.println(modoAutonomo ? "MODO_AUTONOMO" : "MODO_MANUAL");
}

void actualizarLEDs() {
  digitalWrite(LED_AUTONOMO, modoAutonomo);
  digitalWrite(LED_MANUAL, !modoAutonomo);
}

// ========== CALIBRACIÓN ==========
void calibrarSensores() {
  SerialBT.println("CALIBRANDO...");
  
  // Calibrar TCRT
  long sumFront = 0, sumBack = 0;
  for (int i = 0; i < 20; i++) {
    sumFront += analogRead(TCRT_DELANTERO_IZQ) + analogRead(TCRT_DELANTERO_DER);
    sumBack += analogRead(TCRT_TRASERO_IZQ) + analogRead(TCRT_TRASERO_DER);
    delay(50);
  }
  umbralFrontal = (sumFront / 40) + 300;
  umbralTrasero = (sumBack / 40) + 300;
  
  // Calibrar 2Y0
  long sumDist = 0;
  for (int i = 0; i < 20; i++) {
    sumDist += analogRead(PIN_SENSOR_2Y0);
    delay(50);
  }
  UMBRAL_DISTANCIA = (sumDist / 20) + 500;
  
  SerialBT.print("Umbral frontal: "); SerialBT.println(umbralFrontal);
  SerialBT.print("Umbral trasero: "); SerialBT.println(umbralTrasero);
  SerialBT.print("Umbral distancia: "); SerialBT.println(UMBRAL_DISTANCIA);
  SerialBT.println("CALIBRACION_COMPLETADA");
}